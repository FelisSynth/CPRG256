var xhr = new XMLHttpRequest();
var r;
window.onload=loaddata;
function loaddata() {
	document.getElementById("lastName").addEventListener("keyup", function (){ searchLastName(this.value);},false);
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     r = JSON.parse(xhr.responseText);
     getDate();
    }
  };
  xhr.open("GET", "rentalclients.json", true);
  xhr.send();

}

function getDate() {
  var dt = new Date();
  document.getElementById('date-time').innerHTML = dt;
}

function searchLastName(lastName) {
	document.getElementById("searchvalue").innerHTML="Search by Last Name"+"<br>";
	var output="<tr><th>First Name</th><th>Last Name</th><th>Select</th></tr>";
	var searchname;
	for(var i=0; i<r.length; i++)
	{
		var obj=r[i];
		searchname=obj.last_name;
		if(searchname.startsWith(lastName))
		{	
					output+="<tr><td>"
					output+=obj.first_name;
					output+="</td><td>"
					output+=obj.last_name;
					output+="</td><td>";
          output+=`<button onClick="select('${obj.first_name}','${obj.last_name}','${obj.address}','${obj.state_prov}','${obj.email}','${obj.phone}');">Select</button>`;
          output+="<td></tr>";
			}
				
	}
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("results").style.visibility="visible";

}


function select(first_name, last_name, address, state_prov, email, phone) {
    var message = "";
    message += "Client Information: " + "<br>"
    message += "Name: "+ first_name + last_name + "<br>";
    message += "Address: "+ address + "<br>";
    message += "State/Province: "+ state_prov + "<br>";
    message += "Email: "+ email + "<br>";
    message += "Phone: "+ phone + "<br>";
    document.getElementById("selected").innerHTML = message;
    document.getElementById("days").readOnly=false;
}

function sub() {
  var out = "";
  var total = 0;
  var days = document.getElementById("days").value;
  var choice = document.querySelectorAll(`input[name="car"]:checked`)[0].value;
    out += "Rental Information:" + "<br>"
    if (choice == 1) {
      total += 15*days;
      out += "+ Compact ($15/day)" + "<br>";
    } else if (choice == 2) {
      total += 20*days;
      out += "+ Mid-size ($20/day)" + "<br>";
    } else if (choice == 3) {
      total += 35*days;
      out += "+ Luxury ($35/day)" + "<br>";
    } else {
      total += 40*days;
      out += "+ Van/ Truck ($40/day)" + "<br>";
    }
  var rack = document.getElementById("rack").checked;
  var gps = document.getElementById("gps").checked;
  var child = document.getElementById("child").checked;
  if (rack==true) {
    total += 5*days;
    out += "+ Roof Rack or Bycicle Rack ($5/day)" + "<br>";
  }
  if (gps==true) {
    total += 10;
    out += "+ GPS (10$)" + "<br>";
  }
  if (child==true) {
    out += "+ Child Seat (0$)" + "<br>";
  }
  out += "Total: $" + total + " (" + days + " days)";
  document.getElementById("formresult").innerHTML=out;
}
