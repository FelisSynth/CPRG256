function getIncident() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
            document.getElementById("dataset").innerHTML = xhr.responseText;
            incidentSetup();
        }
    };
    xhr.open("GET", "data1.html", true);
    xhr.send();
}

function getProperty() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("dataset").innerHTML = xhr.responseText;
        propertySetup();
        }
    };
    xhr.open("GET", "data2.html", true);
    xhr.send();
}

function getBusiness() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("dataset").innerHTML = xhr.responseText;
        businessSetup();
        }
    };
    xhr.open("GET", "data3.html", true);
    xhr.send();
}

function getPermit() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("dataset").innerHTML = xhr.responseText;
        permitSetup();
        }
    };
    xhr.open("GET", "data4.html", true);
    xhr.send();
}

var xhr = new XMLHttpRequest;
var parsedrecord;
// First Dataset
function incidentSetup() {
    document.getElementById("i_date").addEventListener("keyup", function (){ searchByDate(this.value);},false);
    document.getElementById("i_desc").addEventListener("keyup", function (){ searchByDesc(this.value);},false);
    document.getElementById("i_quadrant").addEventListener("keyup", function (){ searchByQuad(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/35ra-9556.json", true);
  xhr.send();
}

function searchByDate(datee)
{
    var output="<tr><th>Info</th><th>Description</th><th>Quadrant</th><th>Latitude</th><th>Longitute</th><th>Start Date</th><th>Modified</th></tr>";
    var date; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            date=record.start_dt;
            if(date.startsWith(datee))
            {
                output+="<tr><td>";
                output+=record.incident_info;
                output+="</td><td>"
                output+=record.description;
                output+="</td><td>";
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.start_dt;
                output+="</td><td>";
                output+=record.modified_dt;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

function searchByDesc(descr)
{
    var output="<tr><th>Info</th><th>Description</th><th>Quadrant</th><th>Latitude</th><th>Longitute</th><th>Start Date</th><th>Modified</th></tr>";
    var desc; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            desc=record.description;
            if(desc.startsWith(descr))
            {
                output+="<tr><td>";
                output+=record.incident_info;
                output+="</td><td>"
                output+=record.description;
                output+="</td><td>";
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.start_dt;
                output+="</td><td>";
                output+=record.modified_dt;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

function searchByQuad(quadr)
{
    var output="<tr><th>Info</th><th>Description</th><th>Quadrant</th><th>Latitude</th><th>Longitute</th><th>Start Date</th><th>Modified</th></tr>";
    var quad; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            quad=record.quadrant;
            if(quad.startsWith(quadr))
            {
                output+="<tr><td>";
                output+=record.incident_info;
                output+="</td><td>"
                output+=record.description;
                output+="</td><td>";
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.start_dt;
                output+="</td><td>";
                output+=record.modified_dt;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}
//Second Dataset
function propertySetup() {
    document.getElementById("p_property").addEventListener("keyup", function (){ searchByRollNumber(this.value);},false);
    document.getElementById("p_assCode").addEventListener("keyup", function (){ searchByAssessmentClass(this.value);},false);
    document.getElementById("p_key").addEventListener("keyup", function (){ searchByKey(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/simh-5fhj.json", true);
  xhr.send();
	
	
}

function searchByRollNumber(numb)
{
    var output="<tr><th>Roll Year</th><th>Roll Number</th><th>Address</th><th>Latitude</th><th>Longitute</th><th>Assessment Class</th><th>Assesed Value</th><th>Unique Key</th></tr>";
    var rollNumber; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            rollNumber=record.roll_number;
            if(rollNumber.startsWith(numb))
            {
                output+="<tr><td>";
                output+=record.roll_year;
                output+="</td><td>"
                output+=record.roll_number;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.assessment_class;
                output+="</td><td>";
                output+=record.re_assessed_value;
                output+="</td><td>";
                output+=record.unique_key;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";
}
function searchByAssessmentClass(assClass)
{
    var output="<tr><th>Roll Year</th><th>Roll Number</th><th>Address</th><th>Latitude</th><th>Longitute</th><th>Assessment Class</th><th>Assesed Value</th><th>Unique Key</th></tr>";
    var assVal; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            assVal=record.assessment_class;
            if(assVal.startsWith(assClass))
            {
                output+="<tr><td>";
                output+=record.roll_year;
                output+="</td><td>"
                output+=record.roll_number;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.assessment_class;
                output+="</td><td>";
                output+=record.re_assessed_value;
                output+="</td><td>";
                output+=record.unique_key;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}
function searchByKey(keyy)
{
    var output="<tr><th>Roll Year</th><th>Roll Number</th><th>Address</th><th>Latitude</th><th>Longitute</th><th>Assessment Class</th><th>Assesed Value</th><th>Unique Key</th></tr>";
    var key; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            key=record.unique_key;
            if(key.startsWith(keyy))
            {
                output+="<tr><td>";
                output+=record.roll_year;
                output+="</td><td>"
                output+=record.roll_number;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.assessment_class;
                output+="</td><td>";
                output+=record.re_assessed_value;
                output+="</td><td>";
                output+=record.unique_key;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}
//Third Dataset
function businessSetup() {
    document.getElementById("b_quadrant").addEventListener("keyup", function (){ searchByQuadrant(this.value);},false);
    document.getElementById("b_community").addEventListener("keyup", function (){ searchByComunity(this.value);},false);
    document.getElementById("b_collection").addEventListener("keyup", function (){ searchByCollectionDay(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/jq4t-b745.json", true);
  xhr.send();
	
	
}

function searchByQuadrant(quad)
{
    var output="<tr><th>Address</th><th>Quadrant</th><th>Community</th><th>Latitude</th><th>Longitute</th><th>Commodity</th><th>Collection Day</th></tr>";
    var quadrant; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            quadrant=record.quadrant;
            if(quadrant.startsWith(quad))
            {
                output+="<tr><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.community;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.commodity;
                output+="</td><td>";
                output+=record.collection_day;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

function searchByComunity(comm)
{
    var output="<tr><th>Address</th><th>Quadrant</th><th>Community</th><th>Latitude</th><th>Longitute</th><th>Commodity</th><th>Collection Day</th></tr>";
    var community; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            community=record.community;
            if(community.startsWith(comm))
            {
                output+="<tr><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.community;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.commodity;
                output+="</td><td>";
                output+=record.collection_day;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

function searchByCollectionDay(day)
{
    var output="<tr><th>Address</th><th>Quadrant</th><th>Community</th><th>Latitude</th><th>Longitute</th><th>Commodity</th><th>Collection Day</th></tr>";
    var collection; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            collection=record.collection_day;
            if(collection.startsWith(day))
            {
                output+="<tr><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.community;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.commodity;
                output+="</td><td>";
                output+=record.collection_day;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}
//Fourth Dataset
function permitSetup() {
    document.getElementById("f_permit").addEventListener("keyup", function (){ searchByPermit(this.value);},false);
    document.getElementById("f_type").addEventListener("keyup", function (){ searchByType(this.value);},false);
    document.getElementById("f_community").addEventListener("keyup", function (){ searchByCommunity(this.value);},false);

    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/c2es-76ed.json", true);
  xhr.send();
	
	
}

function searchByPermit(perm)
{
    var output="<tr><th>Permit Number</th><th>Permit Type</th><th>Permit Class</th><th>Latitude</th><th>Longitute</th><th>Estimate Project Cost</th><th>Community Name</th></tr>";
    var permit; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            permit=record.permitnum;
            if(permit.startsWith(perm))
            {
                output+="<tr><td>";
                output+=record.permitnum;
                output+="</td><td>"
                output+=record.permittype;
                output+="</td><td>";
                output+=record.permitclass;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.estprojectcost;
                output+="</td><td>";
                output+=record.communityname;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

function searchByType(typee)
{
    var output="<tr><th>Permit Number</th><th>Permit Type</th><th>Permit Class</th><th>Latitude</th><th>Longitute</th><th>Estimate Project Cost</th><th>Community Name</th></tr>";
    var type; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            type=record.permittype;
            if(type.startsWith(typee))
            {
                output+="<tr><td>";
                output+=record.permitnum;
                output+="</td><td>"
                output+=record.permittype;
                output+="</td><td>";
                output+=record.permitclass;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.estprojectcost;
                output+="</td><td>";
                output+=record.communityname;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}


function searchByCommunity(commm)
{
    var output="<tr><th>Permit Number</th><th>Permit Type</th><th>Permit Class</th><th>Latitude</th><th>Longitute</th><th>Estimate Project Cost</th><th>Community Name</th></tr>";
    var com; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            com=record.communityname;
            if(com.startsWith(commm))
            {
                output+="<tr><td>";
                output+=record.permitnum;
                output+="</td><td>"
                output+=record.permittype;
                output+="</td><td>";
                output+=record.permitclass;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.estprojectcost;
                output+="</td><td>";
                output+=record.communityname;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;
    document.getElementById("searchresults").style.visibility="visible";

}

