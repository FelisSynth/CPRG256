function getXMLFile() {
	var xhr = new XMLHttpRequest();
  xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
      processXML(xhr);
    }
  };
  xhr.open("GET", "FinalQuiz.xml", true);
  xhr.send();
}
function processXML(xhr) {
    var i;
    var xmldoc = xhr.responseXML;
    questions = xmldoc.getElementsByTagName("question");
    rightanswers = xmldoc.getElementsByTagName("rightanswers")[0].innerHTML;
    var output = "";
  
    for (i = 0; i <questions.length; i++) { 
        var number = questions[i].getElementsByTagName("qnumber")[0].innerHTML;
        var qtitle = questions[i].getElementsByTagName("qtitle")[0].innerHTML;
        output += `${number}, ${qtitle} <br/>`
        
        var optionA = questions[i].getElementsByTagName("a")[0].innerHTML;
        output += `<input type="radio" value="a" name="question${i+1}"/> a. ${optionA}<br/>`
        var optionB = questions[i].getElementsByTagName("b")[0].innerHTML;
        output += `<input type="radio" value="b" name="question${i+1}"/> b. ${optionB}<br/>`
        var optionC = questions[i].getElementsByTagName("c")[0].innerHTML;
        output += `<input type="radio" value="c" name="question${i+1}"/> c. ${optionC}<br/>`
        var optionD = questions[i].getElementsByTagName("d")[0].innerHTML;
        output += `<input type="radio" value="d" name="question${i+1}"/> d. ${optionD}<br/>`
        output +=  "<br/> <br/>"
      
  }
  document.getElementById("answerDis").innerHTML = output;
}

function grade() {
  var i;
  var j;
    var rightanswerList = rightanswers.split(',');
    // rightanswerList = [b,a,d,a,c]
    var correct = 0;
    var message = "Your score is ";
    var answerList = [];
    for (i = 1; i<questions.length + 1; i++) {
      var answer = document.querySelectorAll(`input[name="question${i}"]:checked`)[0];
      answerList.push(answer.value);
    }
    for (j = 0; j<questions.length; j++) {
      if (rightanswerList[j]==answerList[j]) {
        correct++;
      }
    }
    message += correct;
    message += "/5";
      document.getElementById("grades").innerHTML = message;

}

