function showHide() {
    if (document.getElementById("sheet").checked==true) {
        document.getElementById("sheetcake").style.visibility="visible"
        document.getElementById("roundcake").style.visibility="hidden"
    }
    else if (document.getElementById("round").checked==true) {
        document.getElementById("sheetcake").style.visibility="hidden"
        document.getElementById("roundcake").style.visibility="visible"
    }
}


function calculate() {
    var first = document.getElementById("first").value;
    var last = document.getElementById("last").value;
    var address = document.getElementById("address").value;
    var postal = document.getElementById("postal").value;
    var phone = document.getElementById("phone").value;
    var email = document.getElementById("email").value;
    var layer = document.getElementById("layer").value;
    var cheese = document.getElementById("cheese").checked;
    var fruit = document.getElementById("fruit").checked;
    var jam = document.getElementById("jam").checked;
    var message="";
    var basePrice = parseFloat(0);
    var wholePrice = parseFloat(0);
    var total = parseFloat(0);


    message += first + " " + last + "<br/>";
    message += address + "<br/>";
    message += postal + "<br/>";
    message += phone += "<br/>";
    message += email += "<br/>";
    message += "<br/>";
    message += "Your order:";
    document.getElementById("message").innerHTML=message;
    if (document.getElementById("sheet").checked==true) {
        var width = document.getElementById("width").value;
        var length = document.getElementById("length").value;
        bottomMessage ="Sheet cake " + width + " by " + length + " cm with " + layer + " layers:";
        basePrice = ((width*length)-900)*0.02 + 18;
    }
    else if (document.getElementById("round").checked==true) {
        var radius = document.getElementById("radius").value;
        bottomMessage ="Round cake " + radius + " cm with " + layer + " layers:";
        basePrice = ((Math.pow(radius,2)*Math.PI)-707)*0.02 + 15;
    }
    var layerPrice = (basePrice/2)*(layer-1);
    wholePrice = basePrice + layerPrice;
    total = wholePrice;
    document.getElementById("bottomMessage").innerHTML=bottomMessage;
    document.getElementById("wholePrice").innerHTML="$" + wholePrice.toFixed(2);

    if (cheese==true) {
        total += 5;
        document.getElementById("cheeseMessage").innerHTML="+ Cream Cheese Icing";
        document.getElementById("cheesePrice").innerHTML="$5";
    } else {
        document.getElementById("cheeseMessage").innerHTML="";
        document.getElementById("cheesePrice").innerHTML="";
    }
    if (fruit==true) {
        total += 7;
        document.getElementById("fruitMessage").innerHTML="+ Fruit & Almond topping";
        document.getElementById("fruitPrice").innerHTML="$7";
    } else {
        document.getElementById("fruitMessage").innerHTML="";
        document.getElementById("fruitPrice").innerHTML="";
    }
    if (jam==true) {
        total += 4;
        document.getElementById("jamMessage").innerHTML="+ Jam fillings";
        document.getElementById("jamPrice").innerHTML="$4";
    } else {
        document.getElementById("jamMessage").innerHTML="";
        document.getElementById("jamPrice").innerHTML="";
    }

    document.getElementById("totalMessage").innerHTML="Total:";
    document.getElementById("total").innerHTML="$"+total.toFixed(2);
}