function calculate() {
var onhand = document.getElementById("onhand").value;
var convert = document.getElementById("convert").value;
var amount = parseFloat(document.getElementById("amount").value);
var message = "";

    switch(convert) {
        case "toEUR":
            switch(onhand) {
                case "EUR":
                    message = amount.toFixed(2) + "EUR (1:1)";
                    break;
                case "USD":
                    message = (amount * 0.91667746).toFixed(2) + "EUR (0.916:1)";
                    break;
                case "CAD":
                    message = (amount * 0.72077589).toFixed(2) + "EUR (0.72:1)";
                    break;
                case "BTC":
                    message = (amount * 35527.193).toFixed(2) + "EUR (35527.193:1)";
                    break;
                case "ETH":
                    message = (amount * 2346.2034).toFixed(2) + "EUR (2346.203:1)";
                    break;
            }
        break;

        case "toUSD":
            switch(onhand) {
                case "EUR":
                    message = (amount * 1.0913272).toFixed(2) + "USD (1.091:1)";
                    break;
                case "USD":
                    message = amount.toFixed(2) + "USD (1:1)";
                    break;
                case "CAD":
                    message = (amount * 0.78469961).toFixed(2) + "USD (0.784:1)";
                    break;
                case "BTC":
                    message = (amount * 38802.403).toFixed(2) + "USD (38802.403:1)";
                    break;
                case "ETH":
                    message = (amount * 2559.7955).toFixed(2) + "USD (2559.795:1)";
                    break;
            }
        break;

        case "toCAD":
            switch(onhand) {
                case "EUR":
                    message = (amount * 1.3908861).toFixed(2) + "CAD (1.39:1)";
                    break;
                case "USD":
                    message = (amount * 1.2744222).toFixed(2) + "CAD (1.274:1)";
                    break;
                case "CAD":
                    message = amount.toFixed(2) + "CAD (1:1)";
                    break;
                case "BTC":
                    message = (amount * 49433.712).toFixed(2) + "CAD (49433.712:1)";
                    break;
                case "ETH":
                    message = (amount * 3261.366).toFixed(2) + "CAD (3261.366:1)";
                    break;
            }
        break;

        case "toBTC":
            switch(onhand) {
                case "EUR":
                    message = (amount * 0.00002814163616).toFixed(2) + "XBT (0.0000281:1)";
                    break;
                case "USD":
                    message = (amount * 0.0000257778).toFixed(2) + "XBT (0.0000257:1)";
                    break;
                case "CAD":
                    message = (amount * 0.000020235024278).toFixed(2) + "XBT (0.0000202:1)";
                    break;
                case "BTC":
                    message = amount.toFixed(2) + "XBT (1:1)";
                    break;
                case "ETH":
                    message = (amount * 0.066045343302377).toFixed(2) + "XBT (0.066:1)";
                    break;
            }
        break;

        case "toETH":
            switch(onhand) {
                case "EUR":
                    message = (amount * 0.00042609569052).toFixed(2) + "ETH (0.000426:1)";
                    break;
                case "USD":
                    message = (amount * 0.0003903818).toFixed(2) + "ETH (0.00039:1)";
                    break;
                case "CAD":
                    message = (amount * 0.000305924541206).toFixed(2) + "ETH (0.000305:1)";
                    break;
                case "BTC":
                    message = (amount * 15.11904669547475).toFixed(2) + "ETH (15.119:1)";
                    break;
                case "ETH":
                    message = amount.toFixed(2) + "ETH (1:1)";
                    break;
            }
        break;

    }
     document.getElementById("result").innerHTML=message;
}

