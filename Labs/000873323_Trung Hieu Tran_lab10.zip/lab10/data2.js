var xhr = new XMLHttpRequest;
var parsedrecord;

window.onload=pageSetup;

function pageSetup() {
    document.getElementById("quadrant").addEventListener("keyup", function (){ searchByQuadrant(this.value);},false);
    document.getElementById("community").addEventListener("keyup", function (){ searchByComunity(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/jq4t-b745.json", true);
  xhr.send();
	
	
}

function searchByQuadrant(quad)
{
    var output="<tr><th>Address</th><th>Quadrant</th><th>Community</th><th>Latitude</th><th>Longitute</th><th>Commodity</th><th>Collection Day</th></tr>";
    var quadrant; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            quadrant=record.quadrant;
            if(quadrant.startsWith(quad))
            {
                output+="<tr><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.community;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.commodity;
                output+="</td><td>";
                output+=record.collection_day;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}

function searchByComunity(comm)
{
    var output="<tr><th>Address</th><th>Quadrant</th><th>Community</th><th>Latitude</th><th>Longitute</th><th>Commodity</th><th>Collection Day</th></tr>";
    var community; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            community=record.community;
            if(community.startsWith(comm))
            {
                output+="<tr><td>";
                output+=record.address;
                output+="</td><td>"
                output+=record.quadrant;
                output+="</td><td>";
                output+=record.community;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.commodity;
                output+="</td><td>";
                output+=record.collection_day;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}



