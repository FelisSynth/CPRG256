var xhr = new XMLHttpRequest;
var parsedrecord;

window.onload=pageSetup;

function pageSetup() {
    document.getElementById("property").addEventListener("keyup", function (){ searchByRollNumber(this.value);},false);
    document.getElementById("assVal").addEventListener("keyup", function (){ searchByAssessmentClass(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/simh-5fhj.json", true);
  xhr.send();
	
	
}

function searchByRollNumber(numb)
{
    var output="<tr><th>Roll Year</th><th>Roll Number</th><th>Address</th><th>Latitude</th><th>Longitute</th><th>Assessment Class</th><th>Re-assesed Value</th></tr>";
    var rollNumber; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            rollNumber=record.roll_number;
            if(rollNumber.startsWith(numb))
            {
                output+="<tr><td>";
                output+=record.roll_year;
                output+="</td><td>"
                output+=record.roll_number;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.assessment_class;
                output+="</td><td>";
                output+=record.re_assessed_value;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}

function searchByAssessmentClass(assClass)
{
    var output="<tr><th>Roll Year</th><th>Roll Number</th><th>Address</th><th>Latitude</th><th>Longitute</th><th>Assessment Class</th><th>Re-assesed Value</th></tr>";
    var assVal; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            assVal=record.assessment_class;
            if(assVal.startsWith(assClass))
            {
                output+="<tr><td>";
                output+=record.roll_year;
                output+="</td><td>"
                output+=record.roll_number;
                output+="</td><td>";
                output+=record.address;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.assessment_class;
                output+="</td><td>";
                output+=record.re_assessed_value;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}



