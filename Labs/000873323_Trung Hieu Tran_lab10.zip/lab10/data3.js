var xhr = new XMLHttpRequest;
var parsedrecord;

window.onload=pageSetup;

function pageSetup() {
    document.getElementById("tradename").addEventListener("keyup", function (){ searchByTradeName(this.value);},false);
    document.getElementById("com").addEventListener("keyup", function (){ searchByComDistNM(this.value);},false);
    xhr.onreadystatechange = function() {
    if (xhr.readyState == 4 && xhr.status == 200) {
     parsedrecord = JSON.parse(xhr.responseText);
    }
  };
  xhr.open("GET", "https://data.calgary.ca/resource/vdjc-pybd.json", true);
  xhr.send();
	
	
}

function searchByTradeName(trade)
{
    var output="<tr><th>Trade Name</th><th>Address</th><th>License Type</th><th>Latitude</th><th>Longitute</th><th>ComDistNM</th><th>Job Status Desc</th></tr>";
    var tradename; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            tradename=record.tradename;
            if(tradename.startsWith(trade))
            {
                output+="<tr><td>";
                output+=record.tradename;
                output+="</td><td>"
                output+=record.address;
                output+="</td><td>";
                output+=record.licensetypes;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.comdistnm;
                output+="</td><td>";
                output+=record.jobststusdesc;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}

function searchByComDistNM(com)
{
    var output="<tr><th>Trade Name</th><th>Address</th><th>License Type</th><th>Latitude</th><th>Longitute</th><th>ComDistNM</th><th>Job Status Desc</th></tr>";
    var comdistnm; 
    var gmap;
    var position="";
    for(var i=0;i<parsedrecord.length;i++)
    {
        var record=parsedrecord[i];
            comdistnm=record.comdistnm;
            if(comdistnm.startsWith(com))
            {
                output+="<tr><td>";
                output+=record.tradename;
                output+="</td><td>"
                output+=record.address;
                output+="</td><td>";
                output+=record.licensetypes;
                output+="</td><td>";
                output+=record.latitude;
   
                position=record.latitude;
                position+=","
                output+="</td><td>";
                output+=record.longitude;

                position+=record.longitude;
                output+="</td><td>";
                output+=record.comdistnm;
                output+="</td><td>";
                output+=record.jobststusdesc;
                output+="</td><td>";

                gmap ="<a href=https://www.google.com/maps/search/?api=1&query="+position+" target=_blank>Click here to see map</a> ";
               
              
                output+=gmap;
                
                output+="</td></tr>";
            }
    }
    document.getElementById("searchresults").innerHTML=output;

}



