// function test() {
//     var last=document.getElementById("last").value;
// 	var first=document.getElementById("name").value;
// 	var phone=document.getElementById("phone").value;
// 	var postal=document.getElementById("postal").value;
//     var email=document.getElementById("email").value;
//     var message="";
//     message+= first + " " + last + "<br>";
//     message+=phone + "<br>";
//     message+= postal + "<br>";
//     message+= email + "<br>";

//     document.getElementById("message").innerHTML=message;
// } 
//  (Function to test part A)

var array=[];
var i=0;

function addToArray() {
	var client={last,first,phone,postal,email};
	client.last=document.getElementById("last").value;
	client.first=document.getElementById("first").value;
	client.phone=document.getElementById("phone").value;
	client.postal=document.getElementById("postal").value;
    client.email=document.getElementById("email").value;
	array.push(client);
	displayList();
	
	
}

function displayList() {
	var client;
	var displayRadiobuttons=""
	
	for(var i=0; i< array.length;i++)
 		{
 			
 		var client={last,first,phone,postal,email};
 		client=array[i];

 		client=client.last + " , "+client.first+" , "+client.phone+" , "+client.postal+" , "+client.email;
 		
 		displayRadiobuttons+="<input type=radio name=listitem ";
 		displayRadiobuttons+=" value="+i+" ";
 		displayRadiobuttons+=" onchange=deleteItem(this.value)>";
 		displayRadiobuttons+=client+"<br>";
 		
 		}
 		
document.getElementById("showlist").innerHTML=displayRadiobuttons;
	
}

function deleteItem(i) {
	array.splice(i,1);
	displayList();
	
}