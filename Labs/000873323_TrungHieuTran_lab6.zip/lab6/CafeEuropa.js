function showHide(val,checked) {
    if (val==1&&checked==true) {
        document.getElementById("label1").style.visibility="visible";
    } else if (val==1&&checked!=true) {
        document.getElementById("label1").style.visibility="hidden";
    }
    if (val==2&&checked==true) {
        document.getElementById("label2").style.visibility="visible";
    } else if (val==2&&checked!=true){
        document.getElementById("label2").style.visibility="hidden";
    }
    if (val==3&&checked==true) {
        document.getElementById("label3").style.visibility="visible";
    } else if (val==3&&checked!=true){
        document.getElementById("label3").style.visibility="hidden";
    }
    if (val==4&&checked==true) {
        document.getElementById("label4").style.visibility="visible";
    } else if (val==4&&checked!=true){
        document.getElementById("label4").style.visibility="hidden";
    }
    if (val==5&&checked==true) {
        document.getElementById("label5").style.visibility="visible";
    } else if (val==5&&checked!=true){
        document.getElementById("label5").style.visibility="hidden";
    }
    if (val==6&&checked==true) {
        document.getElementById("label6").style.visibility="visible";
    } else if (val==6&&checked!=true){
        document.getElementById("label6").style.visibility="hidden";
    }
    if (val==7&&checked==true) {
        document.getElementById("label7").style.visibility="visible";
    } else if (val==7&&checked!=true){
        document.getElementById("label7").style.visibility="hidden";
    }
    if (val==8&&checked==true) {
        document.getElementById("label8").style.visibility="visible";
    } else if (val==8&&checked!=true){
        document.getElementById("label8").style.visibility="hidden";
    }
    if (val==9&&checked==true) {
        document.getElementById("label9").style.visibility="visible";
    } else if (val==9&&checked!=true){
        document.getElementById("label9").style.visibility="hidden";
    }
}

function getDate() {
    var dt = new Date();
    document.getElementById('date-time').innerHTML = dt;
}

function calculate() {
    var message="";
    var firstname = document.getElementById("name").value;
    var lastname = document.getElementById("last").value;
    var phone = document.getElementById("phone").value;
    var date = document.getElementById("pickup").value;
     
    var pizza1 = document.getElementById("pizza1").checked;
    var pizza2 = document.getElementById("pizza2").checked;
    var pizza3 = document.getElementById("pizza3").checked;
    var sandwich4 = document.getElementById("sandwich4").checked;
    var sandwich5 = document.getElementById("sandwich5").checked;
    var sandwich6 = document.getElementById("sandwich6").checked;
    var drink7 = document.getElementById("drink7").checked;
    var drink8 = document.getElementById("drink8").checked;
    var drink9 = document.getElementById("drink9").checked;

    var input1 = document.getElementById("input1").value;
    var input2 = document.getElementById("input2").value;
    var input3 = document.getElementById("input3").value;
    var input4 = document.getElementById("input4").value;
    var input5 = document.getElementById("input5").value;
    var input6 = document.getElementById("input6").value;
    var input7 = document.getElementById("input7").value;
    var input8 = document.getElementById("input8").value;
    var input9 = document.getElementById("input9").value;

    var total=parseFloat(0);

    message+=firstname + " " + lastname + "<br>";
    message+=phone + "<br>";
    message+="Pickup: " + date + "<br>";
    message+="<br>"
    
if (pizza1==true) {
    total = total + (12*input1);
    message += input1 + " Margherita" + "<br>"; }
if (pizza2==true) {
    total = total + (12.5*input2);
    message += input2 + " Quattro Formaggi" + "<br>"; }
if (pizza3==true) {
    total = total + (13*input3);
    message += input3 + " Capricciosa" + "<br>"; }
if (sandwich4==true) {
    total = total + (8.5*input4);
    message += input4 + " Schnitzel" + "<br>"; }
if (sandwich5==true) {
    total = total + (9.5*input5);
    message += input5 + " Mixed Grill" + "<br>"; }
if (sandwich6==true) {
    total = total + (10*input6);
    message += input6 + " Big Beef on a Bun" + "<br>"; }
if (drink7==true) {
    total = total + (2*input7);
    message += input7 + " Coffee" + "<br>"; }
if (drink8==true) {
    total = total + (2.5*input8);
    message += input8 + " Latte" + "<br>"; }
if (drink9==true) {
    total = total + (1.75*input9);
    message += input9 + " Soft Drink" + "<br>"; }

    message+="<br>"
    message += "Total order: $" + total.toFixed(2);

	document.getElementById("result").innerHTML=message;
    document.getElementById("results").style.visibility="visible";
}

 