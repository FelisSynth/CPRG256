var visible="false";

function showhide() {
    if (visible=="false") {
        document.getElementById("showfig").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig").style.visibility="hidden";
        visible="false";
    }
}
function showhide2() {
    if (visible=="false") {
        document.getElementById("showfig2").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig2").style.visibility="hidden";
        visible="false";
    }
}
function showhide3() {
    if (visible=="false") {
        document.getElementById("showfig3").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig3").style.visibility="hidden";
        visible="false";
    }
}
function showhide4() {
    if (visible=="false") {
        document.getElementById("showfig4").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig4").style.visibility="hidden";
        visible="false";
    }
}
function showhide5() {
    if (visible=="false") {
        document.getElementById("showfig5").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig5").style.visibility="hidden";
        visible="false";
    }
}
function showhide6() {
    if (visible=="false") {
        document.getElementById("showfig6").style.visibility="visible";
        visible="true";
    } else {
        document.getElementById("showfig6").style.visibility="hidden";
        visible="false";
    }
}