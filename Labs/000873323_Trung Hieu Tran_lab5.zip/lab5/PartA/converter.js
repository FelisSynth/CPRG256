function Length()
{
    var inches=document.getElementById("inches").value;
    inches=parseFloat(inches);
    var cent=parseFloat(0)
    cent=inches*2.54;
    document.getElementById("result").innerHTML=cent.toFixed(2)
}

function Volume() {
    var ounces=document.getElementById("ounces").value;
    counces=parseFloat(ounces);
    var gram=parseFloat(0)
    gram=ounces*28.349523;
    document.getElementById("result2").innerHTML=gram.toFixed(2)
}

function Weight()
{
    var pounds=document.getElementById("pounds").value;
    pounds=parseFloat(pounds);
    var kilos=parseFloat(0)
    kilos=pounds*0.453592;
    document.getElementById("result3").innerHTML=kilos.toFixed(2)
}

function Temperature()
{
    var fah=document.getElementById("fah").value;
    fah=parseFloat(fah);
    var cel=parseFloat(0)
    cel=(fah-32)*.5556;
    document.getElementById("result4").innerHTML=cel.toFixed(2)
}