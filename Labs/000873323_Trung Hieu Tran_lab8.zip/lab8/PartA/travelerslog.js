window.addEventListener("load", registerListeners, false);
var asynchrequest;

function registerListeners() {
	
	var img;
	img=document.getElementById("caption1");
	img.addEventListener("mouseover", function () { getContent("pic1.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
	img=document.getElementById("caption2");
	img.addEventListener("mouseover", function () { getContent("pic2.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
	img=document.getElementById("caption3");
	img.addEventListener("mouseover", function () { getContent("pic3.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
    img=document.getElementById("caption4");
	img.addEventListener("mouseover", function () { getContent("pic4.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
    img=document.getElementById("caption5");
	img.addEventListener("mouseover", function () { getContent("pic5.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
    img=document.getElementById("caption6");
	img.addEventListener("mouseover", function () { getContent("pic6.html");}, false);
	img.addEventListener("mouseout", clearContent, false);
}

function getContent(infopage) {

		asynchrequest = new XMLHttpRequest();
		asynchrequest.onreadystatechange = function() {
    if (asynchrequest.readyState == 4 && asynchrequest.status == 200) {
      document.getElementById("pictures").innerHTML = asynchrequest.responseText;
    }
  };
  asynchrequest.open("GET", infopage, true);
  asynchrequest.send();
}
function clearContent() {
	document.getElementById("pictures").innerHTML="";
}