var temp;
function getSquareForm() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("formBottom").innerHTML = xhr.responseText;
        }
    };
    xhr.open("GET", "square.html", true);
    xhr.send();
    temp = 1;
}

function getCylinderForm() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("formBottom").innerHTML = xhr.responseText;
        }
    };
    xhr.open("GET", "cylinder.html", true);
    xhr.send();
    temp = 2;
}

function getRoundForm() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("formBottom").innerHTML = xhr.responseText;
        }
    };
    xhr.open("GET", "round.html", true);
    xhr.send();
    temp = 3;
}

function getConeForm() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState == 4 && xhr.status == 200) {
        document.getElementById("formBottom").innerHTML = xhr.responseText;
        }
    };
    xhr.open("GET", "cone.html", true);
    xhr.send();
    temp = 4;
}


function calc() {
    var first = document.getElementById("first").value;
    var last = document.getElementById("last").value;
    var address = document.getElementById("address").value;
    var postal = document.getElementById("postal").value;
    var message="";

    message += first + " " + last + "<br/>";
    message += address + "<br/>";
    message += postal + "<br/>";
    message += "<br/>";
    
    var volume = parseFloat(0);
    var total = parseFloat(0);

    if (temp == 1) {
        var width = document.getElementById("width").value;
        var length = document.getElementById("length").value;
        var squareHeight = document.getElementById("squareHeight").value;
        volume = (width*length*squareHeight);
        total = (volume * .001).toFixed(2);
        message += "A rectangular planter with dimensions " + width + " x " + length + " x " + squareHeight + " = " + volume + "cm<sup>3</sup>volume";
        message += "<br/>"
        message += "Cost:" + volume + "x .001 = $" + total;
    } else if (temp == 2) {
        var flatRadius = document.getElementById("flatRadius").value;
        var flatHeight = document.getElementById("flatHeight").value;
        volume = (Math.PI*Math.pow(flatRadius,2)*flatHeight).toFixed(2);
        total = (volume * .0012).toFixed(2);
        message += "A flat bottomed cylinder planter with dimensions 𝜋 x " + flatRadius + "<sup>2</sup>" + " x " + flatHeight + " = " + volume + "cm<sup>3</sup>volume";
        message += "<br/>"
        message += "Cost:" + volume + "x .0012 = $" + total;
    } else if (temp == 3) {
        var roundRadius = document.getElementById("roundRadius").value;
        volume = (1/2 * (4/3 * Math.PI * Math.pow(roundRadius,3))).toFixed(2);
        total = (volume * .0015).toFixed(2);
        message += "A ½ Spherical planter with dimensions 1/2 x (4/3 x 𝜋 x " + roundRadius + "<sup>3</sup> )" + " = " + volume + " cm<sup>3</sup>volume";
        message += "<br/>"
        message += "Cost:" + volume + "x .0015 = $" + total;
    } else if (temp == 4) {
        var coneRadius1 = document.getElementById("coneRadius1").value;
        var coneRadius2 = document.getElementById("coneRadius2").value;
        var coneHeight = document.getElementById("coneHeight").value;
        volume = (1/3 * Math.PI * (Math.pow(coneRadius1,2) + (coneRadius1*coneRadius2) + Math.pow(coneRadius2,2)) * coneHeight).toFixed(2);
        total = (volume * .002).toFixed(2);
        message += "A Truncated Cone planter with dimensions 1/3 x 𝜋 x ( " +coneRadius1+"<sup>2</sup>"+" + "+coneRadius1+" x "+coneRadius2+" + "+coneRadius2+"<sup>2</sup>"+") x "+coneHeight +" = " + volume + " cm<sup>3</sup>volume";
        message += "<br/>"
        message += "Cost:" + volume + " x .002 = $" + total;
    }
   
    document.getElementById("message").innerHTML=message;
}