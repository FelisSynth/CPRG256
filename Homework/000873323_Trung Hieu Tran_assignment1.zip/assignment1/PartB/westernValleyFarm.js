function showHide(val,checked) {
    if (val==1&&checked==true) {
        document.getElementById("label1").style.visibility="visible";
    } else if (val==1&&checked!=true) {
        document.getElementById("label1").style.visibility="hidden";
    }
    if (val==2&&checked==true) {
        document.getElementById("label2").style.visibility="visible";
    } else if (val==2&&checked!=true){
        document.getElementById("label2").style.visibility="hidden";
    }
    if (val==3&&checked==true) {
        document.getElementById("label3").style.visibility="visible";
    } else if (val==3&&checked!=true){
        document.getElementById("label3").style.visibility="hidden";
    }
    if (val==4&&checked==true) {
        document.getElementById("label4").style.visibility="visible";
    } else if (val==4&&checked!=true){
        document.getElementById("label4").style.visibility="hidden";
    }
}
function calculate() {

    var outmessage="";
    var name = document.getElementById("name").value;
    var address = document.getElementById("address").value;
    var delivery = document.getElementById("pickup").value;
    if (pickup==true) {
        var del = "Pickup"
    } else {
        var del = "Delivery"
    }   
    var veg = document.getElementById("Vegetable").checked;
    var fruit = document.getElementById("Fruit").checked;
    var chicken = document.getElementById("Chicken").checked;
    var pork = document.getElementById("Pork").checked;

    var input1 = document.getElementById("input1").value;
    var input2 = document.getElementById("input2").value;
    var input3 = document.getElementById("input3").value;
    var input4 = document.getElementById("input4").value;

    var total=parseFloat(0);

    outmessage+=name + "<br/>";
    outmessage+=address + "<br>";
    outmessage+=del + "<br>";
    outmessage+="<br>"
    outmessage+="Order:" + "<br>";
    outmessage+="<br>"
if (veg==true) {
    total = total + (30*input1);
    outmessage += input1 + " Vegetables Hampers" + "<br>"; }
if (fruit==true) {
    total = total + (20*input2);
    outmessage += input2 + " Fruit Hampers" + "<br>"; }
if (chicken==true) {
    total = total + (7*input3);
    outmessage += input3 + " Fresh Chickens" + "<br>"; }
if (pork==true) {
    total = total + (5*input4);
    outmessage += input4 + " Kg Pork" + "<br>"; }
    outmessage+="<br>"
    outmessage += "Total order: $" + total.toFixed(2);

    alert(outmessage);
	document.getElementById("result").innerHTML=outmessage;
    document.getElementById("results").style.visibility="visible";
}
 